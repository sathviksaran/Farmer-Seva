console.log("Welcome!!!")

var client = require('braintree-web/client');
var paymentRequest = require('braintree-web/payment-request');


var button = document.querySelector('#btn');

braintree.paymentRequest.create({
  client: clientInstance,
  googlePayVersion: 2
}, function (err, instance) {
  if (err) {
    // Handle errors from creating payment request instance
  }

  button.addEventListener('click', function (event) {
    var amount = '100.00';

    instance.tokenize({
      details: {
        total: {
          label: 'Total',
          amount: {
            currency: 'INR',
            value: amount
          }
        }
      }
    }, function (err, payload) {
      if (err) {
        // Handle errors from processing payment request
      }

      // Send payload.nonce to your server
    });
  });
});
